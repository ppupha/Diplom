package pipe.gui.widget;

import javax.swing.*;

public class LoadBinaries {
    private JTextField stateFieldLabel;

    private JTextField transitionFieldLabel;

    private JRadioButton loadFromBinariesRadio;
}
